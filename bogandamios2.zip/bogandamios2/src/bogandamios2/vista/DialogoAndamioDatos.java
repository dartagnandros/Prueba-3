/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.vista;

import bogandamios2.modelo.Andamio; // Asegúrate de importar tu clase Andamio
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Dimension; // No se usa directamente aquí, pero lo mantengo si lo necesitas

public class DialogoAndamioDatos extends JDialog {

    private JTextField txtMarcaInput;
    private JTextField txtPesoInput;
    private JTextField txtValorUnitarioDiaInput;
    private JTextField txtUnidadesInput; // ¡NUEVO CAMPO!
    private JButton btnAceptar;
    private JButton btnCancelar;

    private Andamio andamioResultado = null;
    private boolean modoEdicion = false;

    // Constructor para agregar un nuevo andamio
    public DialogoAndamioDatos(JFrame parent, String titulo) {
        super(parent, titulo, true);
        setSize(400, 300); // Aumentamos la altura para el nuevo campo
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        initComponents();
        addListeners();
        limpiarCampos();
        modoEdicion = false;
        btnAceptar.setText("Agregar");
    }

    // Constructor para editar un andamio existente
    public DialogoAndamioDatos(JFrame parent, String titulo, Andamio andamioAEditar) {
        this(parent, titulo);
        if (andamioAEditar != null) {
            setAndamioParaEdicion(andamioAEditar);
            modoEdicion = true;
            btnAceptar.setText("Actualizar");
        }
    }

    private void initComponents() {
        // Cambiamos el GridLayout a 4 filas para acomodar el nuevo campo
        JPanel panelCampos = new JPanel(new GridLayout(4, 2, 10, 10)); // 4 filas, 2 columnas
        panelCampos.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelCampos.add(new JLabel("Marca:"));
        txtMarcaInput = new JTextField(20);
        panelCampos.add(txtMarcaInput);

        panelCampos.add(new JLabel("Peso (kg):"));
        txtPesoInput = new JTextField(10);
        panelCampos.add(txtPesoInput);

        panelCampos.add(new JLabel("Valor Unitario por Día ($):"));
        txtValorUnitarioDiaInput = new JTextField(10);
        panelCampos.add(txtValorUnitarioDiaInput);

        // ¡NUEVO CAMPO PARA UNIDADES!
        panelCampos.add(new JLabel("Unidades:"));
        txtUnidadesInput = new JTextField(10);
        panelCampos.add(txtUnidadesInput);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnAceptar = new JButton("Aceptar");
        btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnAceptar);
        panelBotones.add(btnCancelar);

        add(panelCampos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void addListeners() {
        btnAceptar.addActionListener(e -> {
            try {
                String marca = txtMarcaInput.getText().trim();
                double peso = Double.parseDouble(txtPesoInput.getText().trim());
                double valor = Double.parseDouble(txtValorUnitarioDiaInput.getText().trim());
                int unidades = Integer.parseInt(txtUnidadesInput.getText().trim()); // ¡LEER UNIDADES!

                if (marca.isEmpty() || peso <= 0 || valor <= 0 || unidades < 0) { // Validar unidades también
                    JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos y asegúrese de que Peso, Valor y Unidades sean válidos (Peso y Valor > 0, Unidades >= 0).", "Datos Inválidos", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (modoEdicion && andamioResultado != null) {
                    andamioResultado.setMarca(marca);
                    andamioResultado.setPeso(peso);
                    andamioResultado.setValorUnitarioDia(valor);
                    andamioResultado.setUnidades(unidades); // ¡ACTUALIZAR UNIDADES!
                } else {
                    andamioResultado = new Andamio(marca, peso, valor, unidades); // ¡CREAR CON UNIDADES!
                }
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese valores numéricos válidos para Peso, Valor Unitario y Unidades.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancelar.addActionListener(e -> {
            andamioResultado = null;
            dispose();
        });
    }

    // Método para pre-llenar los campos si estamos editando un andamio
    public void setAndamioParaEdicion(Andamio andamio) {
        if (andamio != null) {
            this.andamioResultado = andamio;
            txtMarcaInput.setText(andamio.getMarca());
            txtPesoInput.setText(String.valueOf(andamio.getPeso()));
            txtValorUnitarioDiaInput.setText(String.valueOf(andamio.getValorUnitarioDia()));
            txtUnidadesInput.setText(String.valueOf(andamio.getUnidades())); // ¡PRE-LLENAR UNIDADES!
        }
    }

    public Andamio getAndamioResultado() {
        return andamioResultado;
    }

    // Método para limpiar los campos del diálogo
    public void limpiarCampos() {
        txtMarcaInput.setText("");
        txtPesoInput.setText("");
        txtValorUnitarioDiaInput.setText("");
        txtUnidadesInput.setText(""); // ¡LIMPIAR UNIDADES!
        andamioResultado = null;
        modoEdicion = false;
    }
}