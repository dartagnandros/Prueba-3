/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.vista;

/**
 *
 * @author GH
 */

import bogandamios2.controlador.ControladorAndamio;
import bogandamios2.modelo.AndamioDAO;

import bogandamios2.controlador.ControladorCliente; // NUEVO: Importar el controlador de clientes
import bogandamios2.modelo.ClienteDAO;           // NUEVO: Importar el DAO de clientes

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Dimension;

public class VistaPrincipal extends JFrame {

    private JButton btnInventario;
    private JButton btnClientes; // NUEVO: Declaración del botón para Clientes
    // private JButton btnCotizacion; // Sigue eliminado

    public VistaPrincipal() {
        super("Menú Principal de la Aplicación");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 250); // Ajustado para dos botones, puedes modificarlo
        setLocationRelativeTo(null);

        initComponents();
        addListeners();
        
        setVisible(true); 
    }

    private void initComponents() {
        JPanel panelMenu = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 40));

        btnInventario = new JButton("Inventario de Andamios");
        btnInventario.setFont(new Font("Arial", Font.BOLD, 16));
        btnInventario.setPreferredSize(new Dimension(220, 60));

        btnClientes = new JButton("Gestión de Clientes"); // NUEVO: Inicialización del botón Clientes
        btnClientes.setFont(new Font("Arial", Font.BOLD, 16));
        btnClientes.setPreferredSize(new Dimension(220, 60));

        panelMenu.add(btnInventario);
        panelMenu.add(btnClientes); // NUEVO: Adición del botón Clientes al panel

        add(panelMenu);
    }

    private void addListeners() {
        btnInventario.addActionListener(e -> {
            AndamioDAO objetoDAO = new AndamioDAO();
            VistaAndamio objetoVista = new VistaAndamio();
            new ControladorAndamio(objetoDAO, objetoVista);
            // dispose(); // Opcional: Descomentar si quieres cerrar la ventana principal al abrir el inventario
        });

        // NUEVO: Listener para el botón de Clientes
        btnClientes.addActionListener(e -> {
            ClienteDAO clienteDAO = new ClienteDAO(); // Crea una instancia del DAO de Cliente
            VistaCliente vistaCliente = new VistaCliente(); // Crea una instancia de la Vista de Cliente
            new ControladorCliente(clienteDAO, vistaCliente); // Pasa el DAO y la Vista al Controlador de Cliente
            // dispose(); // Opcional: Descomentar si quieres cerrar la ventana principal al abrir la gestión de clientes
        });
    }

    public static void main(String[] args) {
        new VistaPrincipal();
    }
}