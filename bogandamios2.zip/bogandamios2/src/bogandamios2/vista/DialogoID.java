/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.vista;

/**
 *
 * @author GH
 */


import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;

public class DialogoID extends JDialog {

    private JTextField txtIdInput;
    private JButton btnAceptar;
    private int idIngresado = -1; // Valor por defecto si se cancela o no se ingresa nada

    // CONSTRUCTOR CORREGIDO: Ahora acepta el 'titulo' como segundo argumento
    public DialogoID(JFrame parent, String titulo) { // <--- CAMBIO AQUÍ: Añadimos 'String titulo'
        super(parent, titulo, true); // <--- CAMBIO AQUÍ: Pasamos 'titulo' al constructor de JDialog
        setSize(300, 150);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        initComponents();
        addListeners();
    }

    private void initComponents() {
        JPanel panelContenido = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelContenido.add(new JLabel("Ingrese el ID:"));
        
        txtIdInput = new JTextField(15);
        txtIdInput.setPreferredSize(new Dimension(150, 25));
        panelContenido.add(txtIdInput);

        btnAceptar = new JButton("Aceptar");
        panelContenido.add(btnAceptar);

        add(panelContenido, BorderLayout.CENTER);
    }

    private void addListeners() {
        btnAceptar.addActionListener(e -> {
            try {
                idIngresado = Integer.parseInt(txtIdInput.getText().trim());
                dispose();
            } catch (NumberFormatException ex) {
                txtIdInput.setText("");
                txtIdInput.requestFocus();
                JOptionPane.showMessageDialog(this, "Por favor, ingrese un número válido para el ID.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public int getIdIngresado() {
        return idIngresado;
    }
}