package bogandamios2.vista;

import bogandamios2.modelo.Cliente;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class DialogoClienteDatos extends JDialog {

    private JTextField txtNombre;
    private JTextField txtPrimerApellido;  // CAMBIO: txtApellido a txtPrimerApellido
    private JTextField txtSegundoApellido; // NUEVO: Campo para segundo apellido
    private JTextField txtEmail;           // CAMBIO: txtCorreoElectronico a txtEmail
    // private JTextField txtDireccion; // ELIMINADO: Ya no está en el modelo/DB

    private JButton btnAceptar;
    private JButton btnCancelar;

    private Cliente clienteResultado;
    // private boolean datosValidos = false; // Esta variable ya no es estrictamente necesaria aquí, se maneja con 'clienteResultado == null'

    // Constructor para agregar (clienteAEditar es null)
    public DialogoClienteDatos(JFrame parent, String titulo) {
        super(parent, titulo, true); // Modal
        initComponents();
        addListeners();
        pack();
        setLocationRelativeTo(parent);
    }

    // Constructor para editar (clienteAEditar contiene los datos actuales)
    public DialogoClienteDatos(JFrame parent, String titulo, Cliente clienteAEditar) {
        this(parent, titulo); // Llama al constructor de agregar
        if (clienteAEditar != null) {
            setClienteParaEdicion(clienteAEditar);
            this.clienteResultado = clienteAEditar; // Usamos el mismo objeto para la edición
        }
    }

    private void initComponents() {
        // 4 filas para los 4 campos (Nombre, Primer Apellido, Segundo Apellido, Email)
        JPanel panelDatos = new JPanel(new GridLayout(4, 2, 10, 10));
        panelDatos.setBorder(new EmptyBorder(10, 10, 10, 10));

        txtNombre = new JTextField(20);
        txtPrimerApellido = new JTextField(20);  // CAMBIO
        txtSegundoApellido = new JTextField(20); // NUEVO
        txtEmail = new JTextField(20);           // CAMBIO

        panelDatos.add(new JLabel("Nombre:"));
        panelDatos.add(txtNombre);
        panelDatos.add(new JLabel("Primer Apellido:")); // Etiqueta para primer apellido
        panelDatos.add(txtPrimerApellido);
        panelDatos.add(new JLabel("Segundo Apellido:")); // Etiqueta para segundo apellido
        panelDatos.add(txtSegundoApellido);
        panelDatos.add(new JLabel("Email:"));           // Etiqueta para email
        panelDatos.add(txtEmail);
        // ELIMINADO: panelDatos.add(new JLabel("Dirección:"));
        // ELIMINADO: panelDatos.add(txtDireccion);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnAceptar = new JButton("Aceptar");
        btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnAceptar);
        panelBotones.add(btnCancelar);

        add(panelDatos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void addListeners() {
        btnAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCampos()) {
                    if (clienteResultado == null) {
                        // Crea un nuevo Cliente. No incluye ID porque la BD lo genera.
                        // CAMBIO: Pasa primerApellido, segundoApellido, email
                        clienteResultado = new Cliente(
                            txtNombre.getText().trim(),
                            txtPrimerApellido.getText().trim(),
                            txtSegundoApellido.getText().trim(),
                            txtEmail.getText().trim()
                        );
                    } else {
                        // Edita un Cliente existente. El ID ya está en clienteResultado.
                        clienteResultado.setNombre(txtNombre.getText().trim());
                        clienteResultado.setPrimerApellido(txtPrimerApellido.getText().trim()); // CAMBIO
                        clienteResultado.setSegundoApellido(txtSegundoApellido.getText().trim()); // NUEVO
                        clienteResultado.setEmail(txtEmail.getText().trim());                   // CAMBIO
                        // ELIMINADO: clienteResultado.setDireccion(...)
                    }
                    // datosValidos = true; // No es necesario si se usa clienteResultado == null para indicar cancelación
                    dispose();
                } else {
                    // Mensaje de validación ya se muestra en validarCampos()
                }
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clienteResultado = null; // Indica que la operación fue cancelada
                // datosValidos = false;
                dispose();
            }
        });
    }

    public void setClienteParaEdicion(Cliente cliente) {
        if (cliente != null) {
            txtNombre.setText(cliente.getNombre());
            txtPrimerApellido.setText(cliente.getPrimerApellido());  // CAMBIO
            txtSegundoApellido.setText(cliente.getSegundoApellido()); // NUEVO
            txtEmail.setText(cliente.getEmail());                   // CAMBIO
            // ELIMINADO: txtDireccion.setText(...)
        }
    }

    public Cliente getClienteResultado() {
        return clienteResultado;
    }

    private boolean validarCampos() {
        if (txtNombre.getText().trim().isEmpty() ||
            txtPrimerApellido.getText().trim().isEmpty() ||
            txtEmail.getText().trim().isEmpty()) { // Segundo apellido es opcional, no se valida si es nulo aquí
            JOptionPane.showMessageDialog(this, "Nombre, Primer Apellido y Email son obligatorios.", "Campos Faltantes", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        // Opcional: Validación simple de formato de email (regex más robusta sería mejor)
        if (!txtEmail.getText().trim().contains("@") || !txtEmail.getText().trim().contains(".")) {
             JOptionPane.showMessageDialog(this, "Por favor, ingrese un formato de email válido.", "Formato Inválido", JOptionPane.WARNING_MESSAGE);
             return false;
        }
        return true;
    }
}