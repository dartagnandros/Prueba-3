/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.vista;

import bogandamios2.modelo.Andamio; // Importa desde el paquete 'modelo'
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.TitledBorder;

// Importar las clases de diálogo
import bogandamios2.vista.DialogoID;
import bogandamios2.vista.DialogoAndamioDatos;

public class VistaAndamio extends JFrame {

    private JButton btnAgregar;
    private JButton btnBuscar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnVerTodos;

    private JTable tablaAndamios;
    private DefaultTableModel modeloTabla;

    public VistaAndamio() {
        super("Gestión de Andamios");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 600); // Aumentamos un poco el ancho para la nueva columna
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBorder(new TitledBorder("Operaciones de Andamios"));

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnAgregar = new JButton("Agregar");
        btnBuscar = new JButton("Buscar por ID");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar Tabla");
        btnVerTodos = new JButton("Ver Todos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnVerTodos);

        panelSuperior.add(panelBotones, BorderLayout.NORTH);

        // ¡NUEVA COLUMNA AÑADIDA: "Unidades"!
        String[] columnas = {"ID", "Marca", "Peso (kg)", "Valor/Día ($)", "Unidades"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaAndamios = new JTable(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaAndamios);
        scrollTabla.setBorder(new TitledBorder("Lista de Andamios"));

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);

        setVisible(true);
    }

    // --- MÉTODOS PARA SOLICITAR DATOS A TRAVÉS DE POP-UPS ---

    // ¡¡¡ ESTE ES EL MÉTODO CORRECTO Y ÚNICO QUE DEBE ESTAR AQUÍ !!!
    public int solicitarIdParaAccion(String tituloVentana) {
        DialogoID dialogo = new DialogoID(this, tituloVentana); // Pasa 'tituloVentana'
        // No es necesario llamar a dialogo.setTitle() aquí
        dialogo.setVisible(true);
        return dialogo.getIdIngresado();
    }

    public Andamio solicitarDatosAndamio(String tituloVentana, Andamio andamioAEditar) {
        DialogoAndamioDatos dialogo;
        if (andamioAEditar == null) {
            dialogo = new DialogoAndamioDatos(this, tituloVentana);
        } else {
            dialogo = new DialogoAndamioDatos(this, tituloVentana, andamioAEditar);
        }
        dialogo.setVisible(true);
        return dialogo.getAndamioResultado();
    }

    // --- FIN DE MÉTODOS PARA SOLICITAR DATOS ---
    
    public void limpiarCampos() {
        modeloTabla.setRowCount(0);
        mostrarMensaje("Tabla y campos de entrada lógicos limpiados.");
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    public void mostrarAndamiosEnTabla(List<Andamio> listaAndamios) {
        modeloTabla.setRowCount(0);
        if (listaAndamios != null) {
            for (Andamio andamio : listaAndamios) {
                Object[] fila = {
                    andamio.getId(),
                    andamio.getMarca(),
                    andamio.getPeso(),
                    andamio.getValorUnitarioDia(),
                    andamio.getUnidades()
                };
                modeloTabla.addRow(fila);
            }
        }
    }

    // Métodos para añadir escuchadores de eventos a los botones (SIN CAMBIOS EN LAS FIRMAS)
    public void agregarListenerBtnAgregar(ActionListener listenForBtnAgregar) {
        btnAgregar.addActionListener(listenForBtnAgregar);
    }

    public void agregarListenerBtnBuscar(ActionListener listenForBtnBuscar) {
        btnBuscar.addActionListener(listenForBtnBuscar);
    }

    public void agregarListenerBtnActualizar(ActionListener listenForBtnActualizar) {
        btnActualizar.addActionListener(listenForBtnActualizar);
    }

    public void agregarListenerBtnEliminar(ActionListener listenForBtnEliminar) {
        btnEliminar.addActionListener(listenForBtnEliminar);
    }

    public void agregarListenerBtnLimpiar(ActionListener listenForBtnLimpiar) {
        btnLimpiar.addActionListener(listenForBtnLimpiar);
    }

    public void agregarListenerBtnVerTodos(ActionListener listenForBtnVerTodos) {
        btnVerTodos.addActionListener(listenForBtnVerTodos);
    }
}