package bogandamios2.vista;

import bogandamios2.modelo.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class VistaCliente extends JFrame {

    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;

    private JButton btnAgregar;
    private JButton btnBuscar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnVerTodos;

    public VistaCliente() {
        super("Gestión de Clientes");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 500); // Tamaño adecuado para la tabla y botones (ajustado para más columnas)
        setLocationRelativeTo(null);

        initComponents();
        // Los listeners se añadirán desde el controlador
    }

    private void initComponents() {
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnAgregar = new JButton("Agregar Cliente");
        btnBuscar = new JButton("Buscar por ID");
        btnActualizar = new JButton("Actualizar Cliente");
        btnEliminar = new JButton("Eliminar Cliente");
        btnLimpiar = new JButton("Limpiar Tabla");
        btnVerTodos = new JButton("Ver Todos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnVerTodos);

        add(panelBotones, BorderLayout.NORTH);

        // CAMBIO: Columnas de la tabla para coincidir con el nuevo modelo/DB
        String[] columnas = {"ID Cliente", "Nombre", "Primer Apellido", "Segundo Apellido", "Email"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaClientes = new JTable(modeloTabla);
        tablaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void mostrarClientesEnTabla(List<Cliente> clientes) {
        modeloTabla.setRowCount(0);
        if (clientes != null) {
            for (Cliente cliente : clientes) {
                Object[] fila = {
                    cliente.getIdCliente(),      // CAMBIO: getId() a getIdCliente()
                    cliente.getNombre(),
                    cliente.getPrimerApellido(), // CAMBIO: getApellido() a getPrimerApellido()
                    cliente.getSegundoApellido(),// NUEVO
                    cliente.getEmail()           // CAMBIO: getCorreoElectronico() a getEmail()
                    // ELIMINADO: cliente.getDireccion()
                };
                modeloTabla.addRow(fila);
            }
        }
    }

    // Métodos de mensaje, solicitar ID y solicitar datos de cliente (sin cambios funcionales, solo los nombres de los parámetros ya se ajustaron)
    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    public int solicitarIdParaAccion(String titulo) {
        DialogoID dialogo = new DialogoID(this, titulo);
        dialogo.setVisible(true);
        return dialogo.getIdIngresado();
    }

    public Cliente solicitarDatosCliente(String titulo, Cliente clienteAEditar) {
        DialogoClienteDatos dialogo;
        if (clienteAEditar != null) {
            dialogo = new DialogoClienteDatos(this, titulo, clienteAEditar);
        } else {
            dialogo = new DialogoClienteDatos(this, titulo);
        }
        dialogo.setVisible(true);
        return dialogo.getClienteResultado();
    }

    public void limpiarCampos() {
        modeloTabla.setRowCount(0);
        mostrarMensaje("Tabla limpia.");
    }

    // Métodos para Añadir Listeners desde el Controlador (sin cambios en las firmas)
    public void agregarListenerBtnAgregar(ActionListener listener) {
        btnAgregar.addActionListener(listener);
    }

    public void agregarListenerBtnBuscar(ActionListener listener) {
        btnBuscar.addActionListener(listener);
    }

    public void agregarListenerBtnActualizar(ActionListener listener) {
        btnActualizar.addActionListener(listener);
    }

    public void agregarListenerBtnEliminar(ActionListener listener) {
        btnEliminar.addActionListener(listener);
    }

    public void agregarListenerBtnLimpiar(ActionListener listener) {
        btnLimpiar.addActionListener(listener);
    }

    public void agregarListenerBtnVerTodos(ActionListener listener) {
        btnVerTodos.addActionListener(listener);
    }
}