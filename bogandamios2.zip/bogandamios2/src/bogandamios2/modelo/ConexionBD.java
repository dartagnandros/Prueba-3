/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.modelo;


    
    import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase para gestionar la conexión a la base de datos.
 */
public class ConexionBD { // Renombrado a ConexionBD para mayor claridad

    private final String NOMBRE_BD = "bogandamios"; // ¡Base de datos ahora se llama bogandamios!
    private final String URL_CONEXION = "jdbc:mysql://localhost:3306/" + NOMBRE_BD;
    private final String USUARIO = "root";
    private final String CONTRASENA = "";
    private final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private Connection conexion; // Variable de conexión en español

    public Connection conectar() {
        try {
            Class.forName(DRIVER);
            conexion = DriverManager.getConnection(this.URL_CONEXION, this.USUARIO, this.CONTRASENA);
            System.out.println("Se conectó a la base de datos: " + NOMBRE_BD);
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("No se pudo conectar a la base de datos " + NOMBRE_BD + ": " + ex.getMessage());
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conexion;
    }

    public void desconectar() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Se desconectó de la base de datos: " + NOMBRE_BD);
            }
        } catch (SQLException ex) {
            System.err.println("Error al desconectar de la base de datos: " + ex.getMessage());
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Método main opcional para probar la conexión
    public static void main(String[] args) {
        ConexionBD miConexion = new ConexionBD();
        Connection pruebaConexion = miConexion.conectar();
        if (pruebaConexion != null) {
            miConexion.desconectar();
        }
    }
}

