package bogandamios2.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    private ConexionBD conexionBD;

    public ClienteDAO() {
        this.conexionBD = new ConexionBD();
    }

    // --- MÉTODOS CRUD PARA CLIENTE ---

    public boolean agregarCliente(Cliente cliente) {
       
        String sql = "INSERT INTO clientes (nombre, primer_apellido, segundo_apellido, email) VALUES (?, ?, ?, ?)";
        try (Connection con = conexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getPrimerApellido());  // CAMBIO: getApellido() a getPrimerApellido()
            ps.setString(3, cliente.getSegundoApellido()); // NUEVO: setSegundoApellido()
            ps.setString(4, cliente.getEmail());           // CAMBIO: getCorreoElectronico() a getEmail()

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al agregar cliente: " + e.getMessage());
            return false;
        }
    }

    public Cliente obtenerClientePorId(int id) { // El parámetro 'id' se sigue usando para la búsqueda
        // CAMBIO SQL: 'id' a 'id_cliente', 'apellido' a 'primer_apellido', añade 'segundo_apellido', 'correo_electronico' a 'email'
        String sql = "SELECT id_cliente, nombre, primer_apellido, segundo_apellido, email FROM clientes WHERE id_cliente = ?";
        Cliente cliente = null;
        try (Connection con = conexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id); // Se busca por el ID pasado

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente(
                        rs.getInt("id_cliente"),       // CAMBIO: "id" a "id_cliente"
                        rs.getString("nombre"),
                        rs.getString("primer_apellido"), // CAMBIO: "apellido" a "primer_apellido"
                        rs.getString("segundo_apellido"), // NUEVO: "segundo_apellido"
                        rs.getString("email")          // CAMBIO: "correo_electronico" a "email"
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener cliente por ID: " + e.getMessage());
        }
        return cliente;
    }

    public List<Cliente> obtenerTodosLosClientes() {
        
        String sql = "SELECT id_cliente, nombre, primer_apellido, segundo_apellido, email FROM clientes";
        List<Cliente> clientes = new ArrayList<>();
        try (Connection con = conexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cliente cliente = new Cliente(
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("primer_apellido"),
                    rs.getString("segundo_apellido"),
                    rs.getString("email")
                );
                clientes.add(cliente);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener todos los clientes: " + e.getMessage());
        }
        return clientes;
    }

    public boolean actualizarCliente(Cliente cliente) {
        
        String sql = "UPDATE clientes SET nombre = ?, primer_apellido = ?, segundo_apellido = ?, email = ? WHERE id_cliente = ?";
        try (Connection con = conexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getPrimerApellido());  // CAMBIO
            ps.setString(3, cliente.getSegundoApellido()); // NUEVO
            ps.setString(4, cliente.getEmail());           // CAMBIO
            ps.setInt(5, cliente.getIdCliente());          // CAMBIO: getId() a getIdCliente()

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar cliente: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarCliente(int id) { // El parámetro 'id' se sigue usando para la eliminación
        // CAMBIO SQL: 'id' a 'id_cliente'
        String sql = "DELETE FROM clientes WHERE id_cliente = ?";
        try (Connection con = conexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id); // Se elimina por el ID pasado
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar cliente: " + e.getMessage());
            return false;
        }
    }
}