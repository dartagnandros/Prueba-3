/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AndamioDAO {
    private ConexionBD conexionBD;

    public AndamioDAO() {
        this.conexionBD = new ConexionBD();
    }

    // CREATE
    public boolean agregarAndamio(Andamio andamio) {
        // AÑADIDO 'unidades' a la consulta INSERT
        String consultaSQL = "INSERT INTO andamios (marca, peso, valor_unitario_dia, unidades) VALUES (?, ?, ?, ?)";
        Connection conexion = null;
        PreparedStatement sentenciaPreparada = null;
        boolean operacionExitosa = false;

        try {
            conexion = conexionBD.conectar();
            if (conexion == null) {
                System.err.println("No se pudo establecer conexión con la base de datos.");
                return false;
            }
            sentenciaPreparada = conexion.prepareStatement(consultaSQL);
            sentenciaPreparada.setString(1, andamio.getMarca());
            sentenciaPreparada.setDouble(2, andamio.getPeso());
            sentenciaPreparada.setDouble(3, andamio.getValorUnitarioDia());
            sentenciaPreparada.setInt(4, andamio.getUnidades()); // ¡NUEVA LÍNEA! Setear las unidades

            int filasAfectadas = sentenciaPreparada.executeUpdate();
            if (filasAfectadas > 0) {
                operacionExitosa = true;
                System.out.println("Andamio agregado con éxito.");
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar andamio: " + e.getMessage());
        } finally {
            try {
                if (sentenciaPreparada != null) sentenciaPreparada.close();
                if (conexion != null) conexionBD.desconectar();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return operacionExitosa;
    }

    // READ (All)
    public List<Andamio> obtenerTodosLosAndamios() {
        List<Andamio> listaDeAndamios = new ArrayList<>();
        // AÑADIDO 'unidades' a la consulta SELECT
        String consultaSQL = "SELECT id, marca, peso, valor_unitario_dia, unidades FROM andamios";
        Connection conexion = null;
        PreparedStatement sentenciaPreparada = null;
        ResultSet resultados = null;

        try {
            conexion = conexionBD.conectar();
            if (conexion == null) {
                System.err.println("No se pudo establecer conexión con la base de datos.");
                return listaDeAndamios;
            }
            sentenciaPreparada = conexion.prepareStatement(consultaSQL);
            resultados = sentenciaPreparada.executeQuery();

            while (resultados.next()) {
                Andamio andamio = new Andamio();
                andamio.setId(resultados.getInt("id"));
                andamio.setMarca(resultados.getString("marca"));
                andamio.setPeso(resultados.getDouble("peso"));
                andamio.setValorUnitarioDia(resultados.getDouble("valor_unitario_dia"));
                andamio.setUnidades(resultados.getInt("unidades")); // ¡NUEVA LÍNEA! Leer las unidades
                listaDeAndamios.add(andamio);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener andamios: " + e.getMessage());
        } finally {
            try {
                if (resultados != null) resultados.close();
                if (sentenciaPreparada != null) sentenciaPreparada.close();
                if (conexion != null) conexionBD.desconectar();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return listaDeAndamios;
    }

    // READ (By ID)
    public Andamio obtenerAndamioPorId(int idAndamio) {
        Andamio andamioEncontrado = null;
        // AÑADIDO 'unidades' a la consulta SELECT
        String consultaSQL = "SELECT id, marca, peso, valor_unitario_dia, unidades FROM andamios WHERE id = ?";
        Connection conexion = null;
        PreparedStatement sentenciaPreparada = null;
        ResultSet resultados = null;

        try {
            conexion = conexionBD.conectar();
            if (conexion == null) {
                System.err.println("No se pudo establecer conexión con la base de datos.");
                return null;
            }
            sentenciaPreparada = conexion.prepareStatement(consultaSQL);
            sentenciaPreparada.setInt(1, idAndamio);
            resultados = sentenciaPreparada.executeQuery();

            if (resultados.next()) {
                andamioEncontrado = new Andamio();
                andamioEncontrado.setId(resultados.getInt("id"));
                andamioEncontrado.setMarca(resultados.getString("marca"));
                andamioEncontrado.setPeso(resultados.getDouble("peso"));
                andamioEncontrado.setValorUnitarioDia(resultados.getDouble("valor_unitario_dia"));
                andamioEncontrado.setUnidades(resultados.getInt("unidades")); // ¡NUEVA LÍNEA! Leer las unidades
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener andamio por ID: " + e.getMessage());
        } finally {
            try {
                if (resultados != null) resultados.close();
                if (sentenciaPreparada != null) sentenciaPreparada.close();
                if (conexion != null) conexionBD.desconectar();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return andamioEncontrado;
    }

    // UPDATE
    public boolean actualizarAndamio(Andamio andamio) {
        // AÑADIDO 'unidades' a la consulta UPDATE
        String consultaSQL = "UPDATE andamios SET marca = ?, peso = ?, valor_unitario_dia = ?, unidades = ? WHERE id = ?";
        Connection conexion = null;
        PreparedStatement sentenciaPreparada = null;
        boolean operacionExitosa = false;

        try {
            conexion = conexionBD.conectar();
            if (conexion == null) {
                System.err.println("No se pudo establecer conexión con la base de datos.");
                return false;
            }
            sentenciaPreparada = conexion.prepareStatement(consultaSQL);
            sentenciaPreparada.setString(1, andamio.getMarca());
            sentenciaPreparada.setDouble(2, andamio.getPeso());
            sentenciaPreparada.setDouble(3, andamio.getValorUnitarioDia());
            sentenciaPreparada.setInt(4, andamio.getUnidades()); // ¡NUEVA LÍNEA! Setear las unidades
            sentenciaPreparada.setInt(5, andamio.getId()); // El ID es el último parámetro para el WHERE

            int filasAfectadas = sentenciaPreparada.executeUpdate();
            if (filasAfectadas > 0) {
                operacionExitosa = true;
                System.out.println("Andamio actualizado con éxito.");
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar andamio: " + e.getMessage());
        } finally {
            try {
                if (sentenciaPreparada != null) sentenciaPreparada.close();
                if (conexion != null) conexionBD.desconectar();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return operacionExitosa;
    }

    // DELETE (No necesita cambios, ya que solo depende del ID)
    public boolean eliminarAndamio(int idAndamio) {
        String consultaSQL = "DELETE FROM andamios WHERE id = ?";
        Connection conexion = null;
        PreparedStatement sentenciaPreparada = null;
        boolean operacionExitosa = false;

        try {
            conexion = conexionBD.conectar();
            if (conexion == null) {
                System.err.println("No se pudo establecer conexión con la base de datos.");
                return false;
            }
            sentenciaPreparada = conexion.prepareStatement(consultaSQL);
            sentenciaPreparada.setInt(1, idAndamio);

            int filasAfectadas = sentenciaPreparada.executeUpdate();
            if (filasAfectadas > 0) {
                operacionExitosa = true;
                System.out.println("Andamio eliminado con éxito.");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar andamio: " + e.getMessage());
        } finally {
            try {
                if (sentenciaPreparada != null) sentenciaPreparada.close();
                if (conexion != null) conexionBD.desconectar();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return operacionExitosa;
    }
}