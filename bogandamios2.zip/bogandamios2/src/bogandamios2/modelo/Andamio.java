/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.modelo;

/**
 *
 * @author GH
 */
public class Andamio {
    private int id;
    private String marca;
    private double peso;
    private double valorUnitarioDia;
    private int unidades; // ¡NUEVO ATRIBUTO!

    // Constructores
    public Andamio() {
    }

    // Constructor existente, actualizado para incluir unidades (sin ID)
    public Andamio(String marca, double peso, double valorUnitarioDia, int unidades) {
        this.marca = marca;
        this.peso = peso;
        this.valorUnitarioDia = valorUnitarioDia;
        this.unidades = unidades; // Inicializa el nuevo atributo
    }

    // Constructor existente, actualizado para incluir unidades (con ID)
    public Andamio(int id, String marca, double peso, double valorUnitarioDia, int unidades) {
        this.id = id;
        this.marca = marca;
        this.peso = peso;
        this.valorUnitarioDia = valorUnitarioDia;
        this.unidades = unidades; // Inicializa el nuevo atributo
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getValorUnitarioDia() {
        return valorUnitarioDia;
    }

    public void setValorUnitarioDia(double valorUnitarioDia) {
        this.valorUnitarioDia = valorUnitarioDia;
    }
    
    // ¡Nuevos Getters y Setters para 'unidades'!
    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Marca: " + marca + ", Peso: " + peso + " kg, Valor/Día: $" + valorUnitarioDia + ", Unidades: " + unidades;
    }
}