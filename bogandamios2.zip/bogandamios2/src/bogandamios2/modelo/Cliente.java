package bogandamios2.modelo;

public class Cliente {
    private int idCliente; // CAMBIO: 'id' a 'idCliente' para coincidir con id_cliente
    private String nombre;
    private String primerApellido; // CAMBIO: 'apellido' a 'primerApellido'
    private String segundoApellido; // NUEVO CAMPO: para 'segundo_apellido'
    private String email;          // CAMBIO: 'correoElectronico' a 'email'
    // private String direccion; // ELIMINADO: Ya no está en tu CREATE TABLE

    // Constructor vacío
    public Cliente() {
    }

    // Constructor para agregar un nuevo cliente (sin ID, ya que la BD lo asigna)
    // CAMBIO: 'apellido' a 'primerApellido', añade 'segundoApellido', 'correoElectronico' a 'email', elimina 'direccion'
    public Cliente(String nombre, String primerApellido, String segundoApellido, String email) {
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.email = email;
    }

    // Constructor para recuperar o actualizar un cliente (con ID)
    // CAMBIO: 'id' a 'idCliente', 'apellido' a 'primerApellido', añade 'segundoApellido', 'correoElectronico' a 'email', elimina 'direccion'
    public Cliente(int idCliente, String nombre, String primerApellido, String segundoApellido, String email) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.email = email;
    }

    // Getters
    public int getIdCliente() { // CAMBIO: getId() a getIdCliente()
        return idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrimerApellido() { // CAMBIO: getApellido() a getPrimerApellido()
        return primerApellido;
    }

    public String getSegundoApellido() { // NUEVO: Getter para segundoApellido
        return segundoApellido;
    }

    public String getEmail() { // CAMBIO: getCorreoElectronico() a getEmail()
        return email;
    }

    // ELIMINADO: getDireccion()

    // Setters
    public void setIdCliente(int idCliente) { // CAMBIO: setId() a setIdCliente()
        this.idCliente = idCliente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrimerApellido(String primerApellido) { // CAMBIO: setApellido() a setPrimerApellido()
        this.primerApellido = primerApellido;
    }

    public void setSegundoApellido(String segundoApellido) { // NUEVO: Setter para segundoApellido
        this.segundoApellido = segundoApellido;
    }

    public void setEmail(String email) { // CAMBIO: setCorreoElectronico() a setEmail()
        this.email = email;
    }

    // ELIMINADO: setDireccion()

    @Override
    public String toString() {
        return "Cliente{" +
               "idCliente=" + idCliente +
               ", nombre='" + nombre + '\'' +
               ", primerApellido='" + primerApellido + '\'' +
               ", segundoApellido='" + segundoApellido + '\'' +
               ", email='" + email + '\'' +
               '}';
    }
}