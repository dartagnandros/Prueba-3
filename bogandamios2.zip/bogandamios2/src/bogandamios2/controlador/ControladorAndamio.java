/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bogandamios2.controlador;

import bogandamios2.modelo.Andamio;
import bogandamios2.modelo.AndamioDAO;
import bogandamios2.vista.VistaAndamio;
import bogandamios2.vista.DialogoID;
import bogandamios2.vista.DialogoAndamioDatos;
import bogandamios2.vista.VistaPrincipal; // Mantengo esta importación por si se usa en main, aunque no directamente en el controlador
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

public class ControladorAndamio {
    private AndamioDAO modeloDatos;
    private VistaAndamio vistaInterfaz;

    public ControladorAndamio(AndamioDAO modelo, VistaAndamio vista) {
        this.modeloDatos = modelo;
        this.vistaInterfaz = vista;

        // Añadir escuchadores a los botones de la vista
        this.vistaInterfaz.agregarListenerBtnAgregar(new ListenerBtnAgregar());
        this.vistaInterfaz.agregarListenerBtnBuscar(new ListenerBtnBuscar());
        this.vistaInterfaz.agregarListenerBtnActualizar(new ListenerBtnActualizar());
        this.vistaInterfaz.agregarListenerBtnEliminar(new ListenerBtnEliminar());
        this.vistaInterfaz.agregarListenerBtnLimpiar(new ListenerBtnLimpiar());
        this.vistaInterfaz.agregarListenerBtnVerTodos(new ListenerBtnVerTodos());

        // Al iniciar, cargar todos los andamios en la tabla
        cargarTodosLosAndamios();
    }

    // Método para cargar y mostrar todos los andamios en la tabla
    private void cargarTodosLosAndamios() {
        List<Andamio> listaAndamios = modeloDatos.obtenerTodosLosAndamios();
        vistaInterfaz.mostrarAndamiosEnTabla(listaAndamios);
    }

    // Clase interna para manejar el botón "Agregar"
    class ListenerBtnAgregar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                // Solicita los datos del nuevo andamio a través del pop-up.
                // El DialogoAndamioDatos ahora captura también las "unidades".
                Andamio nuevoAndamio = vistaInterfaz.solicitarDatosAndamio("Agregar Nuevo Andamio", null);

                if (nuevoAndamio != null) { // Verifica si el usuario no canceló el diálogo
                    // El objeto 'nuevoAndamio' ya contendrá las 'unidades'
                    if (modeloDatos.agregarAndamio(nuevoAndamio)) {
                        vistaInterfaz.mostrarMensaje("Andamio agregado exitosamente.");
                        cargarTodosLosAndamios(); // Recarga la tabla para mostrar el nuevo andamio
                    } else {
                        vistaInterfaz.mostrarMensaje("Error al agregar andamio.");
                    }
                } else {
                    vistaInterfaz.mostrarMensaje("Operación de agregar andamio cancelada.");
                }
            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al procesar datos para agregar: " + ex.getMessage());
            }
        }
    }

    // Clase interna para manejar el botón "Buscar por ID"
    class ListenerBtnBuscar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int idBuscar = vistaInterfaz.solicitarIdParaAccion("Buscar Andamio por ID");

                if (idBuscar <= 0) {
                    vistaInterfaz.mostrarMensaje("Operación de búsqueda cancelada o ID inválido.");
                    return;
                }
                
                Andamio andamioEncontrado = modeloDatos.obtenerAndamioPorId(idBuscar);
                if (andamioEncontrado != null) {
                    vistaInterfaz.mostrarMensaje("Andamio encontrado (ID: " + andamioEncontrado.getId() + ", Marca: " + andamioEncontrado.getMarca() + ", Unidades: " + andamioEncontrado.getUnidades() + ").");
                    // Muestra solo el andamio encontrado en la tabla
                    vistaInterfaz.mostrarAndamiosEnTabla(List.of(andamioEncontrado));
                } else {
                    vistaInterfaz.mostrarMensaje("Andamio no encontrado con ID: " + idBuscar);
                    vistaInterfaz.mostrarAndamiosEnTabla(List.of()); // Limpia la tabla si no se encuentra
                }
            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al buscar andamio: " + ex.getMessage());
            }
        }
    }

    // Clase interna para manejar el botón "Actualizar"
    class ListenerBtnActualizar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int idAActualizar = vistaInterfaz.solicitarIdParaAccion("Actualizar Andamio - Ingrese ID");
                
                if (idAActualizar <= 0) {
                    vistaInterfaz.mostrarMensaje("Operación de actualización cancelada o ID inválido.");
                    return;
                }

                Andamio andamioExistente = modeloDatos.obtenerAndamioPorId(idAActualizar);
                if (andamioExistente == null) {
                    vistaInterfaz.mostrarMensaje("Andamio con ID " + idAActualizar + " no encontrado para actualizar.");
                    return;
                }

                // Abre el pop-up con los datos existentes, incluyendo las 'unidades'.
                // El usuario modifica los campos y el mismo objeto 'andamioExistente' se actualiza.
                Andamio andamioActualizado = vistaInterfaz.solicitarDatosAndamio("Actualizar Andamio", andamioExistente);

                if (andamioActualizado != null) { // Verifica si el usuario no canceló el diálogo
                    // El objeto 'andamioActualizado' (que es el mismo 'andamioExistente')
                    // ya tendrá las nuevas 'unidades' si el usuario las modificó.
                    if (modeloDatos.actualizarAndamio(andamioActualizado)) {
                        vistaInterfaz.mostrarMensaje("Andamio actualizado exitosamente.");
                        cargarTodosLosAndamios(); // Recarga la tabla con los datos actualizados
                    } else {
                        vistaInterfaz.mostrarMensaje("Error al actualizar andamio. Verifique el ID o los datos.");
                    }
                } else {
                    vistaInterfaz.mostrarMensaje("Operación de actualización cancelada.");
                }

            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al procesar datos para actualizar: " + ex.getMessage());
            }
        }
    }

    // Clase interna para manejar el botón "Eliminar"
    class ListenerBtnEliminar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int idEliminar = vistaInterfaz.solicitarIdParaAccion("Eliminar Andamio - Ingrese ID");

                if (idEliminar <= 0) {
                    vistaInterfaz.mostrarMensaje("Operación de eliminación cancelada o ID inválido.");
                    return;
                }

                int confirmacion = JOptionPane.showConfirmDialog(vistaInterfaz,
                    "¿Está seguro de que desea eliminar el andamio con ID " + idEliminar + "?",
                    "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    if (modeloDatos.eliminarAndamio(idEliminar)) {
                        vistaInterfaz.mostrarMensaje("Andamio eliminado exitosamente.");
                        cargarTodosLosAndamios(); // Recarga la tabla para reflejar la eliminación
                    } else {
                        vistaInterfaz.mostrarMensaje("Error al eliminar andamio o ID no encontrado.");
                    }
                }
            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al eliminar andamio: " + ex.getMessage());
            }
        }
    }

    // Clase interna para manejar el botón "Limpiar Tabla"
    class ListenerBtnLimpiar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            vistaInterfaz.limpiarCampos(); // Ahora limpia la tabla y mensajes.
        }
    }

    // Clase interna para manejar el botón "Ver Todos"
    class ListenerBtnVerTodos implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            cargarTodosLosAndamios(); // Recarga y muestra todos los andamios
        }
    }

    // Método main para iniciar la aplicación (Asumiendo que VistaPrincipal es tu punto de entrada principal)
    public static void main(String[] args) {
        new VistaPrincipal();
    }
}