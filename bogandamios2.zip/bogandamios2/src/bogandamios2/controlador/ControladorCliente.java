package bogandamios2.controlador;

import bogandamios2.modelo.Cliente;
import bogandamios2.modelo.ClienteDAO;
import bogandamios2.vista.VistaCliente;
// import bogandamios2.vista.DialogoID; // Ya no es necesario importar aquí si VistaCliente lo encapsula

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

public class ControladorCliente {
    private ClienteDAO modeloDatos;
    private VistaCliente vistaInterfaz;

    public ControladorCliente(ClienteDAO modelo, VistaCliente vista) {
        this.modeloDatos = modelo;
        this.vistaInterfaz = vista;

        this.vistaInterfaz.agregarListenerBtnAgregar(new ListenerBtnAgregar());
        this.vistaInterfaz.agregarListenerBtnBuscar(new ListenerBtnBuscar());
        this.vistaInterfaz.agregarListenerBtnActualizar(new ListenerBtnActualizar());
        this.vistaInterfaz.agregarListenerBtnEliminar(new ListenerBtnEliminar());
        this.vistaInterfaz.agregarListenerBtnLimpiar(new ListenerBtnLimpiar());
        this.vistaInterfaz.agregarListenerBtnVerTodos(new ListenerBtnVerTodos());

        cargarTodosLosClientes();
        this.vistaInterfaz.setVisible(true);
    }

    private void cargarTodosLosClientes() {
        List<Cliente> listaClientes = modeloDatos.obtenerTodosLosClientes();
        vistaInterfaz.mostrarClientesEnTabla(listaClientes);
    }

    class ListenerBtnAgregar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Cliente nuevoCliente = vistaInterfaz.solicitarDatosCliente("Agregar Nuevo Cliente", null);
                if (nuevoCliente != null) {
                    if (modeloDatos.agregarCliente(nuevoCliente)) {
                        vistaInterfaz.mostrarMensaje("Cliente agregado exitosamente.");
                        cargarTodosLosClientes();
                    } else {
                        vistaInterfaz.mostrarMensaje("Error al agregar cliente.");
                    }
                } else {
                    vistaInterfaz.mostrarMensaje("Operación de agregar cliente cancelada.");
                }
            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al procesar datos para agregar: " + ex.getMessage());
            }
        }
    }

    class ListenerBtnBuscar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int idBuscar = vistaInterfaz.solicitarIdParaAccion("Buscar Cliente por ID");
                if (idBuscar <= 0) {
                    vistaInterfaz.mostrarMensaje("Operación de búsqueda cancelada o ID inválido.");
                    return;
                }
                
                Cliente clienteEncontrado = modeloDatos.obtenerClientePorId(idBuscar);
                if (clienteEncontrado != null) {
                    // C A M B I O S   A Q U Í
                    vistaInterfaz.mostrarMensaje("Cliente encontrado (ID: " + clienteEncontrado.getIdCliente() + ", Nombre: " + clienteEncontrado.getNombre() + ", Correo: " + clienteEncontrado.getEmail() + ").");
                    vistaInterfaz.mostrarClientesEnTabla(List.of(clienteEncontrado));
                } else {
                    vistaInterfaz.mostrarMensaje("Cliente no encontrado con ID: " + idBuscar);
                    vistaInterfaz.mostrarClientesEnTabla(List.of());
                }
            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al buscar cliente: " + ex.getMessage());
            }
        }
    }

    class ListenerBtnActualizar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int idAActualizar = vistaInterfaz.solicitarIdParaAccion("Actualizar Cliente - Ingrese ID");
                if (idAActualizar <= 0) {
                    vistaInterfaz.mostrarMensaje("Operación de actualización cancelada o ID inválido.");
                    return;
                }

                Cliente clienteExistente = modeloDatos.obtenerClientePorId(idAActualizar);
                if (clienteExistente == null) {
                    vistaInterfaz.mostrarMensaje("Cliente con ID " + idAActualizar + " no encontrado para actualizar.");
                    return;
                }

                Cliente clienteActualizado = vistaInterfaz.solicitarDatosCliente("Actualizar Cliente", clienteExistente);
                if (clienteActualizado != null) {
                    if (modeloDatos.actualizarCliente(clienteActualizado)) {
                        vistaInterfaz.mostrarMensaje("Cliente actualizado exitosamente.");
                        cargarTodosLosClientes();
                    } else {
                        vistaInterfaz.mostrarMensaje("Error al actualizar cliente. Verifique el ID o los datos.");
                    }
                } else {
                    vistaInterfaz.mostrarMensaje("Operación de actualización cancelada.");
                }

            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al procesar datos para actualizar: " + ex.getMessage());
            }
        }
    }

    class ListenerBtnEliminar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int idEliminar = vistaInterfaz.solicitarIdParaAccion("Eliminar Cliente - Ingrese ID");
                if (idEliminar <= 0) {
                    vistaInterfaz.mostrarMensaje("Operación de eliminación cancelada o ID inválido.");
                    return;
                }

                int confirmacion = JOptionPane.showConfirmDialog(vistaInterfaz,
                    "¿Está seguro de que desea eliminar el cliente con ID " + idEliminar + "?",
                    "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    if (modeloDatos.eliminarCliente(idEliminar)) {
                        vistaInterfaz.mostrarMensaje("Cliente eliminado exitosamente.");
                        cargarTodosLosClientes();
                    } else {
                        vistaInterfaz.mostrarMensaje("Error al eliminar cliente o ID no encontrado.");
                    }
                }
            } catch (Exception ex) {
                vistaInterfaz.mostrarMensaje("Error al eliminar cliente: " + ex.getMessage());
            }
        }
    }

    class ListenerBtnLimpiar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            vistaInterfaz.limpiarCampos();
        }
    }

    class ListenerBtnVerTodos implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            cargarTodosLosClientes();
        }
    }
}